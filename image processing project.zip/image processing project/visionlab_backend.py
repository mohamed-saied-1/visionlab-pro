"""
╔══════════════════════════════════════════════════════╗
║  VisionLab Pro  ·  FastAPI Backend  v2.1.0 (fixed)  ║
║  Run: uvicorn visionlab_backend:app --reload         ║
║  Install: pip install fastapi uvicorn opencv-python  ║
║           numpy scikit-image pillow python-multipart ║
╚══════════════════════════════════════════════════════╝
"""
import base64, io, time, warnings
import numpy as np
import cv2
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Any, Dict, List
from PIL import Image
warnings.filterwarnings("ignore")

try:
    from skimage import data as skdata, filters as skfilters
    SKI = True
except ImportError:
    SKI = False

# ── Config ────────────────────────────────────────────────────
MAX_PIXELS = 4_000_000

# ── App ──────────────────────────────────────────────────────
app = FastAPI(title="VisionLab Pro API", version="2.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# ══════════════════════════════════════════════════════════════
# UTILITIES
# ══════════════════════════════════════════════════════════════

def b64_to_np(b64: str) -> np.ndarray:
    raw = b64.split(",")[-1]

    pil = Image.open(io.BytesIO(base64.b64decode(raw)))

    if pil.mode not in ("RGB", "L"):
        pil = pil.convert("RGB")

    img = np.array(pil, dtype=np.uint8)

    h, w = img.shape[:2]

    if h * w > MAX_PIXELS:
        scale = (MAX_PIXELS / (h * w)) ** 0.5

        img = cv2.resize(
            img,
            (int(w * scale), int(h * scale)),
            interpolation=cv2.INTER_AREA
        )

    return img


def np_to_b64(img: np.ndarray, q: int = 88) -> str:
    img = _u8(img)

    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

    buf = io.BytesIO()

    Image.fromarray(img).save(
        buf,
        format="WEBP",
        quality=q
    )

    return "data:image/webp;base64," + \
           base64.b64encode(buf.getvalue()).decode()


def _u8(img: np.ndarray) -> np.ndarray:
    if img is None:
        return None

    if img.dtype == bool:
        return (img * 255).astype(np.uint8)

    if img.dtype in (np.float32, np.float64):
        img = img * 255 if img.max() <= 1.0 else img

    return np.clip(img, 0, 255).astype(np.uint8)


def _gray(img: np.ndarray) -> np.ndarray:
    if img.ndim == 2:
        return img

    return (
        0.299 * img[:, :, 0] +
        0.587 * img[:, :, 1] +
        0.114 * img[:, :, 2]
    ).astype(np.uint8)


def _rgb(img: np.ndarray) -> np.ndarray:
    if img.ndim == 2:
        return cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

    return img[:, :, :3] if img.shape[2] == 4 else img


def _hist(img: np.ndarray) -> List[int]:
    g = _gray(img) if img.ndim == 3 else img
    return np.bincount(g.ravel(), minlength=256).tolist()


def _peak(h: List[int]) -> int:
    nz = sorted(v for v in h if v > 0)
    return max(nz[int(len(nz) * 0.95)], 1) if nz else 1


def _stats(img: np.ndarray) -> dict:
    g = _gray(img)

    h, w = img.shape[:2]
    ch = img.shape[2] if img.ndim == 3 else 1

    return {
        "w": int(w),
        "h": int(h),
        "ch": int(ch),
        "dtype": str(img.dtype),
        "sz": f"{img.nbytes // 1024} KB",
        "mn": int(g.min()),
        "mx": int(g.max()),
        "mean": round(float(g.mean()), 1),
        "std": round(float(g.std()), 1),
    }


def _snr(orig: np.ndarray, proc: np.ndarray) -> float:
    o = _gray(orig).astype(np.float32)
    p = _gray(proc).astype(np.float32)

    d = float(np.sum((o - p) ** 2))

    if d > 0:
        return round(
            float(
                10 * np.log10(float(np.sum(o ** 2)) / d)
            ),
            2
        )

    return 9999.0


# ══════════════════════════════════════════════════════════════
# PROCESSING HELPERS
# ══════════════════════════════════════════════════════════════

def _apply_per_channel(img, fn):
    if img.ndim == 2:
        return fn(img)

    channels = []

    for c in range(3):
        channels.append(fn(img[:, :, c]))

    return np.stack(channels, axis=2)


def _solar(g, T, dark):
    r = g.copy()

    m = r < T if dark else r > T

    r[m] = 255 - r[m]

    return r


def _stretch(img):
    if img.ndim == 2:
        lo, hi = int(img.min()), int(img.max())

        if hi == lo:
            return img

        return np.clip(
            (img.astype(np.float32) - lo) * 255 / (hi - lo),
            0,
            255
        ).astype(np.uint8)

    out = np.zeros_like(img)

    for c in range(3):
        ch = img[:, :, c]

        lo, hi = int(ch.min()), int(ch.max())

        if hi == lo:
            out[:, :, c] = ch
        else:
            out[:, :, c] = np.clip(
                (ch.astype(np.float32) - lo) * 255 / (hi - lo),
                0,
                255
            ).astype(np.uint8)

    return out


def _equalize(img):
    if img.ndim == 2:
        return cv2.equalizeHist(img)

    ycrcb = cv2.cvtColor(_rgb(img), cv2.COLOR_RGB2YCrCb)

    ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])

    return cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2RGB)


def _kern(g, K):
    return np.clip(
        cv2.filter2D(g.astype(np.float32), -1, K),
        0,
        255
    ).astype(np.uint8)


def _sobel(g):
    gx = cv2.Sobel(g, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_64F, 0, 1, ksize=3)

    return np.clip(
        np.hypot(gx, gy),
        0,
        255
    ).astype(np.uint8)


def _prewitt(g):
    f = g.astype(np.float32)

    Kx = np.array([
        [-1, 0, 1],
        [-1, 0, 1],
        [-1, 0, 1]
    ], np.float32)

    Ky = np.array([
        [-1, -1, -1],
        [0, 0, 0],
        [1, 1, 1]
    ], np.float32)

    return np.clip(
        np.hypot(
            cv2.filter2D(f, -1, Kx),
            cv2.filter2D(f, -1, Ky)
        ),
        0,
        255
    ).astype(np.uint8)


def _nsp(g, r):
    n = g.copy()

    t = int(r * n.size)

    n.flat[np.random.randint(0, n.size, t)] = 255
    n.flat[np.random.randint(0, n.size, t)] = 0

    return n


def _ngauss(g, s):
    return np.clip(
        g.astype(np.float32) +
        np.random.normal(0, s, g.shape),
        0,
        255
    ).astype(np.uint8)


def _otsu(g):
    if SKI:
        return (
            g >= skfilters.threshold_otsu(g)
        ).astype(np.uint8) * 255

    _, r = cv2.threshold(
        g,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    return r


def _fs(g):
    try:
        pil = Image.fromarray(g)

        try:
            d = pil.convert(
                "1",
                dither=Image.Dither.FLOYDSTEINBERG
            )
        except AttributeError:
            d = pil.convert(
                "1",
                dither=Image.FLOYDSTEINBERG
            )

        return np.array(d).astype(np.uint8) * 255

    except Exception:
        return _otsu(g)


# ── Bonus / AI helpers ───────────────────────────────────────

def _face(img):
    """Haar-cascade face + eye detection (colour output)."""
    rgb   = _rgb(img)
    gray  = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    fc    = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    ec    = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_eye.xml")
    faces = fc.detectMultiScale(gray, 1.1, 5, minSize=(30, 30))
    out   = rgb.copy()
    count = 0
    if len(faces):
        count = len(faces)
        for (x, y, w, h) in faces:
            cv2.rectangle(out, (x, y), (x + w, y + h), (139, 92, 246), 3)
            cv2.putText(out, "Face", (x, y - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, .65, (99, 209, 238), 2)
            roi_gray = gray[y:y + h, x:x + w]
            for (ex, ey, ew, eh) in ec.detectMultiScale(roi_gray):
                cv2.rectangle(out,
                              (x + ex, y + ey),
                              (x + ex + ew, y + ey + eh),
                              (239, 68, 68), 2)
    return out, int(count)


def _kmeans(img, k):
    """K-means colour quantisation."""
    src  = _rgb(img)
    Z    = src.reshape(-1, 3).astype(np.float32)
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, .2)
    _, labels, centres = cv2.kmeans(
        Z, k, None, crit, 10, cv2.KMEANS_RANDOM_CENTERS)
    return np.uint8(centres)[labels.flatten()].reshape(src.shape)


def _watershed(img):
    """Marker-based watershed segmentation (colour output)."""
    rgb = _rgb(img)
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    g   = _gray(img)
    _, th = cv2.threshold(g, 0, 255,
                          cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    se  = np.ones((3, 3), np.uint8)
    op  = cv2.morphologyEx(th, cv2.MORPH_OPEN,  se, iterations=2)
    bg  = cv2.dilate(op, se, iterations=3)
    dt  = cv2.distanceTransform(op, cv2.DIST_L2, 5)
    _, fg = cv2.threshold(dt, .5 * dt.max(), 255, 0)
    fg  = np.uint8(fg)
    _, mk = cv2.connectedComponents(fg)
    mk  = mk + 1
    mk[cv2.subtract(bg, fg) == 255] = 0
    cv2.watershed(bgr, mk)
    bgr[mk == -1] = [139, 92, 246]
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def _grabcut(img):
    """GrabCut foreground/background separation (colour output)."""
    rgb = _rgb(img)
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    h, w = bgr.shape[:2]

    # Guard against very small images
    margin = min(h, w) // 8
    rx, ry = margin, margin
    rw = w - 2 * margin
    rh = h - 2 * margin
    if rw <= 0 or rh <= 0:
        rx, ry = w // 8, h // 8
        rw = max(w - 2 * (w // 8), 1)
        rh = max(h - 2 * (h // 8), 1)

    rect = (rx, ry, rw, rh)
    mask = np.zeros((h, w), np.uint8)
    bM   = np.zeros((1, 65), np.float64)
    fM   = np.zeros((1, 65), np.float64)
    cv2.grabCut(bgr, mask, rect, bM, fM, 5, cv2.GC_INIT_WITH_RECT)
    fg   = np.where((mask == 2) | (mask == 0), 0, 1).astype(np.uint8)
    bg   = np.full_like(rgb, [5, 5, 12])
    out  = bg.copy()
    out[fg == 1] = rgb[fg == 1]
    return out


def _clahe(img):
    """Contrast Limited Adaptive Histogram Equalisation (colour-aware)."""
    if img.ndim == 2:
        return cv2.createCLAHE(3., (8, 8)).apply(img)
    lab = cv2.cvtColor(_rgb(img), cv2.COLOR_RGB2LAB)
    lab[:, :, 0] = cv2.createCLAHE(3., (8, 8)).apply(lab[:, :, 0])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)


# ══════════════════════════════════════════════════════════════
# MAIN ROUTER
# ══════════════════════════════════════════════════════════════

def run_op(img: np.ndarray, op: str, p: dict):

    g = _gray(img)

    meta = {}

    k = lambda n, d: p.get(n, d)

    # ── Lab 1-3 ──────────────────────────────────────────────

    if op == "gray_w":
        res = g

    elif op == "gray_avg":
        res = np.mean(img, axis=2).astype(np.uint8)

    elif op == "ch_r":
        res = img.copy()

        if img.ndim == 3:
            res[:, :, 1] = 0
            res[:, :, 2] = 0

    elif op == "ch_g":
        res = img.copy()

        if img.ndim == 3:
            res[:, :, 0] = 0
            res[:, :, 2] = 0

    elif op == "ch_b":
        res = img.copy()

        if img.ndim == 3:
            res[:, :, 0] = 0
            res[:, :, 1] = 0

    # ── Lab 4: Point Operations (FIXED RGB SUPPORT) ───────────────
    elif op == "add":
        res = _apply_per_channel(
            img,
            lambda x: np.clip(x.astype(np.int32) + k("c", 50), 0, 255).astype(np.uint8)
            )

    elif op == "sub":
        res = _apply_per_channel(
            img,
            lambda x: np.clip(x.astype(np.int32) - k("c", 50), 0, 255).astype(np.uint8)
            )

    elif op == "mul":
        res = _apply_per_channel(
            img,
            lambda x: np.clip(x.astype(np.float32) * k("f", 2.0), 0, 255).astype(np.uint8)
            )

    elif op == "div":
        res = _apply_per_channel(
            img,
            lambda x: np.clip(
                x.astype(np.float32) / max(k("f", 2.0), 1e-9),
                0, 255
            ).astype(np.uint8)
        )

    elif op == "neg":
        res = _apply_per_channel(
            img,
            lambda x: (255 - x).astype(np.uint8)
            )

    elif op == "solar_d":
        res = _apply_per_channel(
            img,
            lambda x: _solar(x, k("T", 128), True)
            )

    elif op == "solar_b":
        res = _apply_per_channel(
            img,
            lambda x: _solar(x, k("T", 128), False)
            )
    # ── Lab 5 ────────────────────────────────────────────────

    elif op == "stretch":
        res = _stretch(img)

    elif op == "equalize":
        res = _equalize(img)

    elif op == "blend":

        if k("image2", ""):

            i2 = cv2.resize(
                _rgb(b64_to_np(k("image2", ""))),
                (img.shape[1], img.shape[0])
            )

            a = k("alpha", .6)

            res = np.clip(
                a * _rgb(img).astype(np.float32) +
                (1 - a) * i2.astype(np.float32),
                0,
                255
            ).astype(np.uint8)

        else:
            res = img

    elif op == "isub":

        if k("image2", ""):

            i2 = cv2.resize(
                _rgb(b64_to_np(k("image2", ""))),
                (img.shape[1], img.shape[0])
            )

            res = np.clip(
                _rgb(img).astype(np.int32) -
                i2.astype(np.int32),
                0,
                255
            ).astype(np.uint8)

        else:
            res = img

    # ── Lab 6 ────────────────────────────────────────────────

    elif op == "mean":

        kk = k("k", 3)

        res = _apply_per_channel(
            img,
            lambda x: cv2.blur(x, (kk, kk))
        )

    elif op == "median":

        kk = k("k", 3)
        kk = kk if kk % 2 else kk + 1

        res = _apply_per_channel(
            img,
            lambda x: cv2.medianBlur(x, kk)
        )

    elif op == "fmin":

        kk = k("k", 3)

        kernel = np.ones((kk, kk), np.uint8)

        res = _apply_per_channel(
            img,
            lambda x: cv2.erode(x, kernel)
        )

    elif op == "fmax":

        kk = k("k", 3)

        kernel = np.ones((kk, kk), np.uint8)

        res = _apply_per_channel(
            img,
            lambda x: cv2.dilate(x, kernel)
        )

    # ── Lab 7-8 ──────────────────────────────────────────────

    elif op == "savg":

        kk = k("k", 3)

        res = _apply_per_channel(
            img,
            lambda x: _kern(
                x,
                np.ones((kk, kk), np.float32) / kk ** 2
            )
        )

    elif op == "sgauss":

        kk = k("k", 5)

        kk = kk if kk % 2 else kk + 1

        res = _apply_per_channel(
            img,
            lambda x: cv2.GaussianBlur(
                x,
                (kk, kk),
                k("sigma", 1.5)
            )
        )

    elif op == "sharp":

        kernel = np.array([
            [-1, -1, -1],
            [-1,  9, -1],
            [-1, -1, -1]
        ], np.float32)

        res = _apply_per_channel(
            img,
            lambda x: _kern(x, kernel)
        )

    elif op == "lap":

        res = _apply_per_channel(
            img,
            lambda x: np.clip(
                np.abs(
                    cv2.Laplacian(x, cv2.CV_64F)
                ),
                0,
                255
            ).astype(np.uint8)
        )

    elif op == "sobel":

        res = _apply_per_channel(
            img,
            lambda x: _sobel(x)
        )

    elif op == "prewitt":

        res = _apply_per_channel(
            img,
            lambda x: _prewitt(x)
        )

    # ── Lab 9 ────────────────────────────────────────────────

    elif op == "nsp":

        res = _apply_per_channel(
            img,
            lambda x: _nsp(x, k("r", .05))
        )

        meta["snr"] = _snr(img, res)

    elif op == "ngauss":

        res = _apply_per_channel(
            img,
            lambda x: _ngauss(x, k("s", 25))
        )

        meta["snr"] = _snr(img, res)

    elif op == "restore":

        noisy = _apply_per_channel(
            img,
            lambda x: _nsp(x, k("r", .05))
        )

        method = k("method", "median")

        kk = k("k", 3)

        if method == "median":

            kk = kk if kk % 2 else kk + 1

            res = _apply_per_channel(
                noisy,
                lambda x: cv2.medianBlur(x, kk)
            )

        elif method == "gaussian":

            kk = kk if kk % 2 else kk + 1

            res = _apply_per_channel(
                noisy,
                lambda x: cv2.GaussianBlur(
                    x,
                    (kk, kk),
                    1.
                )
            )

        else:

            res = _apply_per_channel(
                noisy,
                lambda x: cv2.blur(x, (kk, kk))
            )

        meta["snr_noisy"] = _snr(img, noisy)
        meta["snr_restored"] = _snr(img, res)
        meta["noisy"] = np_to_b64(noisy)

    # ── Lab 10 ───────────────────────────────────────────────

    elif op == "dilate":

        kk = k("k", 5)

        kernel = np.ones((kk, kk), np.uint8)

        res = _apply_per_channel(
            img,
            lambda x: cv2.dilate(x, kernel)
        )

    elif op == "erode":

        kk = k("k", 5)

        kernel = np.ones((kk, kk), np.uint8)

        res = _apply_per_channel(
            img,
            lambda x: cv2.erode(x, kernel)
        )

    elif op == "mopen":

        kk = k("k", 5)

        kernel = np.ones((kk, kk), np.uint8)

        res = _apply_per_channel(
            img,
            lambda x: cv2.morphologyEx(
                x,
                cv2.MORPH_OPEN,
                kernel
            )
        )

    elif op == "mclose":

        kk = k("k", 5)

        kernel = np.ones((kk, kk), np.uint8)

        res = _apply_per_channel(
            img,
            lambda x: cv2.morphologyEx(
                x,
                cv2.MORPH_CLOSE,
                kernel
            )
        )

    elif op == "mgrad":

        kk = k("k", 5)

        kernel = np.ones((kk, kk), np.uint8)

        res = _apply_per_channel(
            img,
            lambda x: cv2.morphologyEx(
                x,
                cv2.MORPH_GRADIENT,
                kernel
            )
        )

    # ── Lab 11 ───────────────────────────────────────────────

    elif op == "otsu":

        res = _otsu(g)

        if SKI:
            meta["threshold"] = round(
                float(skfilters.threshold_otsu(g)),
                2
            )

    elif op == "manual":

        T = k("T", 128)

        res = (g >= T).astype(np.uint8) * 255

    elif op == "adaptive":

        res = cv2.adaptiveThreshold(
            g,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            11,
            2
        )

    elif op == "fs":

        res = _fs(g)

    # ── Canny edge (Bonus) ────────────────────────────────────

    elif op == "canny":
        res = cv2.Canny(g, k("lo", 50), k("hi", 150))

    # ── AI / Bonus algorithms ─────────────────────────────────

    elif op == "face":
        res, n        = _face(img)
        meta["faces"] = n                    # plain Python int ✓

    elif op == "kmeans":
        res = _kmeans(img, k("k", 3))

    elif op == "watershed":
        res = _watershed(img)

    elif op == "grabcut":
        res = _grabcut(img)

    elif op == "clahe":
        res = _clahe(img)

    else:
        raise HTTPException(400, f"Unknown operation: {op}")

    return _u8(res), meta


# ══════════════════════════════════════════════════════════════
# MODELS
# ══════════════════════════════════════════════════════════════

class ProcessReq(BaseModel):
    image: str
    operation: str
    params: Dict[str, Any] = {}


class UploadReq(BaseModel):
    image: str


class SampleReq(BaseModel):
    name: str


# ══════════════════════════════════════════════════════════════
# ENDPOINTS
# ══════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return {
        "status": "ok",
        "service": "VisionLab Pro API"
    }


# ── scikit-image sample catalogue ────────────────────────────

_SAMPLE_FNS = {
    "astronaut": lambda: skdata.astronaut(),
    "camera":    lambda: skdata.camera(),
    "coins":     lambda: skdata.coins(),
    "chelsea":   lambda: skdata.chelsea(),
    "rocket":    lambda: skdata.rocket(),
    "moon":      lambda: skdata.moon(),
    "coffee":    lambda: skdata.coffee(),
    "horse":     lambda: skdata.horse(),
}

SAMPLES = list(_SAMPLE_FNS.keys())


@app.get("/api/samples")
def list_samples():
    return {"samples": SAMPLES}


@app.post("/api/sample")
def get_sample(req: SampleReq):
    if not SKI:
        raise HTTPException(503, "scikit-image not installed")
    fn = _SAMPLE_FNS.get(req.name)
    if not fn:
        raise HTTPException(400, f"Unknown sample: {req.name}")
    img = _u8(fn())
    h   = _hist(img)
    ch_hists = (
        [_hist(img[:, :, i]) for i in range(3)]
        if img.ndim == 3 else None
    )
    return {
        "image":         np_to_b64(img),
        "info":          _stats(img),
        "histogram":     h,
        "peak":          _peak(h),
        "ch_histograms": ch_hists,
    }


@app.post("/api/upload")
def upload(req: UploadReq):

    img = b64_to_np(req.image)

    h = _hist(img)

    ch_hists = (
        [_hist(img[:, :, i]) for i in range(3)]
        if img.ndim == 3 else None
    )

    return {
        "image":         np_to_b64(img),
        "info":          _stats(img),
        "histogram":     h,
        "peak":          _peak(h),
        "ch_histograms": ch_hists,
    }


@app.post("/api/process")
def process(req: ProcessReq):

    try:

        t0 = time.perf_counter()

        img = b64_to_np(req.image)

        result, meta = run_op(
            img,
            req.operation,
            req.params
        )

        latency_ms = round(
            (time.perf_counter() - t0) * 1000,
            1
        )

        ho = _hist(img)
        hr = _hist(result)

        return {
            "result": np_to_b64(result),
            "original": np_to_b64(img),
            "hist_orig": ho,
            "hist_result": hr,
            "peak_orig": _peak(ho),
            "peak_result": _peak(hr),
            "meta": meta,
            "latency_ms": latency_ms,
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(500, str(e))


if __name__ == "__main__":

    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=True
    )