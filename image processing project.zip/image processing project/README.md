# 🔬 VisionLab Pro — CS303 Image Processing

> **Full-stack image processing suite** — FastAPI backend + React/Tailwind frontend
> Covers **Labs 1–11** + **5 bonus AI algorithms**

---

## 🚀 Quick Start (2 steps)

### Step 1 — Backend
```bash
pip install -r requirements.txt
uvicorn visionlab_backend:app --reload --port 8000
```
Backend runs at → `http://localhost:8000`
API docs at    → `http://localhost:8000/docs`

### Step 2 — Frontend
Open `visionlab_frontend.html` in your browser.
*(No build step, no npm — pure React via CDN)*

---

## 📁 Files

| File | Purpose |
|------|---------|
| `visionlab_backend.py` | FastAPI server — all image processing |
| `visionlab_frontend.html` | React UI — Space Grotesk + Inter + Tailwind |
| `requirements.txt` | Python dependencies |

---

## ✅ Features Covered

### Labs 1–11
| Lab | Operations |
|-----|-----------|
| Lab 1–2 | Image info, RGB channels, grayscale conversions |
| Lab 3 | Weighted/avg grayscale, channel decomposition |
| Lab 4 | Add, subtract, multiply, divide, complement, solarize |
| Lab 5 | Histogram stretching, equalization, blending, subtraction |
| Lab 6 | Mean, median, min, max neighbourhood filters |
| Lab 7–8 | Average, Gaussian, sharpening, Laplacian, Sobel, Prewitt |
| Lab 9 | Salt & pepper noise, Gaussian noise, restoration + SNR |
| Lab 10 | Dilation, erosion, opening, closing, gradient |
| Lab 11 | Otsu, manual, adaptive threshold, Floyd-Steinberg dither |

### Bonus AI Algorithms (+5)
| Algorithm | Method |
|-----------|--------|
| Face Detection | Haar Cascade (Viola–Jones) |
| K-Means Segmentation | Lloyd's algorithm |
| Watershed | Topographic flooding |
| Background Removal | GrabCut (graph-cut) |
| CLAHE | Contrast Limited Adaptive HE |
| Edge Detection | Canny |

---

## 🎨 UI Design

- **Colors**: Black `#030308` + Purple `#7C3AED` + Red `#EF4444` + Blue `#3B82F6`
- **Fonts**: Space Grotesk (headings) + Inter (body) + JetBrains Mono (code)
- **Animations**: Floating orbs, fade-up entries, glow pulses, shimmer bars
- **Components**: Glassmorphism cards, drag-to-compare slider, animated canvas histogram

---

## 🛠 Tech Stack

**Backend**: FastAPI · OpenCV · NumPy · scikit-image · Pillow
**Frontend**: React 18 (CDN) · Tailwind CSS (CDN) · Babel Standalone · Google Fonts
